The test cases are in the "sketch_asm.ino" files.
